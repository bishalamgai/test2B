package com.example.lab2_bishalamgai;

public class Products {
    private int Id;

    private String ProductName;

    private String  Category;

    private  int Price;

    private  int StockQuantity;

    public Products(int id, String productName, String category, int price, int stockQuantity) {
        Id = id;
        ProductName = productName;
        Category = category;
        Price = price;
        StockQuantity = stockQuantity;
    }

    public int getId() {
        return Id;
    }

    public void setId(int id) {
        Id = id;
    }

    public String getProductName() {
        return ProductName;
    }

    public void setProductName(String productName) {
        ProductName = productName;
    }

    public String getCategory() {
        return Category;
    }

    public void setCategory(String category) {
        Category = category;
    }

    public int getPrice() {
        return Price;
    }

    public void setPrice(int price) {
        Price = price;
    }

    public int getStockQuantity() {
        return StockQuantity;
    }

    public void setStockQuantity(int stockQuantity) {
        StockQuantity = stockQuantity;
    }
}
