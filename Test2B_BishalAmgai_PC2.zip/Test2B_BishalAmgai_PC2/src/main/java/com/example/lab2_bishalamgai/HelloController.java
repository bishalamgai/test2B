package com.example.lab2_bishalamgai;


import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import java.sql.*;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import java.net.URL;
import java.util.ResourceBundle;
public class HelloController implements Initializable {

    public Label messageText;
    @FXML
    private TableView<Products> tableView;
    @FXML
    private TableColumn<Products,Integer > Id;
    @FXML
    private TableColumn<Products, String> ProductName;
    @FXML
    private TableColumn<Products, String> Category;
    @FXML
    private TableColumn<Products,Integer> Price;
    @FXML
    private TableColumn<Products,Integer> StockQuantity;
    @FXML
    public TextField Pname;
    @FXML
    public TextField Pcategory;
    @FXML
    public TextField Pprice;
    @FXML
    public TextField Pstock;
    ObservableList<Products> list = FXCollections.observableArrayList();
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        Id.setCellValueFactory(new
                PropertyValueFactory<Products,Integer>("Id"));
        ProductName.setCellValueFactory(new
                PropertyValueFactory<Products,String>("ProductName"));
        Category.setCellValueFactory(new
                PropertyValueFactory<Products,String>("Category"));
        Price.setCellValueFactory(new
                PropertyValueFactory<Products,Integer>("Price"));
        StockQuantity.setCellValueFactory(new
                PropertyValueFactory<Products,Integer>("StockQuantity"));
        tableView.setItems(list);
    }

    public void ViewData() {
// Establish a database connection
        String jdbcUrl = "jdbc:mysql://localhost:3306/test2b_bishal_amgai_pc2";
        String dbUser = "root";
        String dbPassword = "";
        try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUser,
                dbPassword)) {
// Execute a SQL query to retrieve data from the database
            String query = "SELECT * FROM product_management";
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(query);
            tableView.getItems().clear();

// Populate the table with data from the database
            while (resultSet.next()) {
                int Id = resultSet.getInt("Id");
                String ProductName = resultSet.getString("ProductName");
                String Category = resultSet.getString("Category");
                int Price = resultSet.getInt("Price");
                int StockQuantity = resultSet.getInt("StockQuantity");
                tableView.getItems().add(new Products(Id, ProductName, Category,
                        Price, StockQuantity));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void Insert(ActionEvent actionEvent) {
        String pname= Pname.getText();
        String pcategory= Pcategory.getText();
        String pprice= Pprice.getText();
        String pstock= Pstock.getText();

        InsertTable(pname,pcategory,pprice,pstock);
    }

    public void InsertTable(String pname,String pcategory,String pprice,String pstock) {
// Establish a database connection
        String jdbcUrl = "jdbc:mysql://localhost:3306/test2b_bishal_amgai_pc2";
        String dbUser = "root";
        String dbPassword = "";
        try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUser,
                dbPassword)) {
// Execute a SQL query to retrieve data from the database
            String query = "INSERT INTO `product_management`( `ProductName`, `Category`, `Price`, `StockQuantity`) VALUES ('"+pname+"','"+pcategory+"','"+pprice+"','"+pstock+"')";
            Statement statement = connection.createStatement();
            statement.execute(query);
            ViewData();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @FXML
    public void delete() {
        Products selectedProduct = tableView.getSelectionModel().getSelectedItem();
        if (selectedProduct != null) {
            int productId = selectedProduct.getId();
            deleteProductFromDatabase(productId);
        } else {
            messageText.setText("Please select a product to delete.");
        }
    }

    @FXML
    public void update() {
        Products selectedProduct = tableView.getSelectionModel().getSelectedItem();
        if (selectedProduct != null) {
            int productId = selectedProduct.getId();
            String newName = Pname.getText();
            String newCategory = Pcategory.getText();
            int newPrice = Integer.parseInt(Pprice.getText());
            int newStockQuantity = Integer.parseInt(Pstock.getText());

            updateProductInDatabase(productId, newName, newCategory, newPrice, newStockQuantity);
        } else {
            messageText.setText("Please select a product to update.");
        }
    }


    private void deleteProductFromDatabase(int productId) {
        String jdbcUrl = "jdbc:mysql://localhost:3306/test2b_bishal_amgai_pc2";
        String dbUser = "root";
        String dbPassword = "";
        try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUser, dbPassword)) {
            String query = "DELETE FROM product_management WHERE Id=?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, productId);
            preparedStatement.executeUpdate();
            messageText.setText("Product deleted successfully.");
            // Refresh TableView
            ViewData();
        } catch (SQLException e) {
            messageText.setText("Error occurred while deleting product: " + e.getMessage());
        }
    }

    // Method to update product in the database
    private void updateProductInDatabase(int productId, String newName, String newCategory, int newPrice, int newStockQuantity) {
        String jdbcUrl = "jdbc:mysql://localhost:3306/test2b_bishal_amgai_pc2";
        String dbUser = "root";
        String dbPassword = "";
        try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUser, dbPassword)) {
            String query = "UPDATE product_management SET ProductName=?, Category=?, Price=?, StockQuantity=? WHERE Id=?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, newName);
            preparedStatement.setString(2, newCategory);
            preparedStatement.setInt(3, newPrice);
            preparedStatement.setInt(4, newStockQuantity);
            preparedStatement.setInt(5, productId);
            preparedStatement.executeUpdate();
            messageText.setText("Product updated successfully.");
            // Refresh TableView
            ViewData();
        } catch (SQLException e) {
            messageText.setText("Error occurred while updating product: " + e.getMessage());
        }
    }

    public void set_username(String messge){
        messageText.setText(messge);
    }
}










